Directory 
-- R_DSCL_Filter_RL78_CubeSuite+
             - Contains the RL78 workspace sample on CubeSuite+ using the DSCL library

-- R_DSCL_Filter_RL78_IARwb
             - Contains the RL78 workspace sample IAR Embedded Workbench using the DSCL library